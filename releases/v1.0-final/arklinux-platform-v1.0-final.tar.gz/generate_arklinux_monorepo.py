#!/usr/bin/env python3
"""Generate the arklinux-platform monorepo artifact set.

This script writes a deterministic directory tree containing:
- Master spec
- JSON schemas
- systemd unit templates
- nftables rules
- snapshot tooling
- package manifest template

It is intentionally offline and contains no network calls.
"""

from __future__ import annotations

import argparse
import os
import shutil
from pathlib import Path

ASSETS = {
    "docs/ARKLinux_A_R_K_Master_Spec_v1.md": "arklinux_spec_v1.md",
    "schemas/SAL_schema.json": "SAL_schema.json",
    "schemas/MDS_schema.json": "MDS_schema.json",
    "schemas/CPA_schema.json": "CPA_schema.json",
    "schemas/VerifiedClaim_schema.json": "VerifiedClaim_schema.json",
    "schemas/ParameterArtifact_schema.json": "ParameterArtifact_schema.json",
    "network/nftables/arklinux.nft": "arklinux.nft",
    "system/snapshots/btrfs_snapshot.sh": "btrfs_snapshot.sh",
    "manifests/package_manifest_template.json": "package_manifest_template.json",
}

PLAN_SCHEMA = r'''{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://arklinux.example.com/schemas/plan.schema.json",
  "title": "Execution Plan",
  "type": "object",
  "additionalProperties": false,
  "properties": {
    "plan_id": { "type": "string" },
    "plan_hash": { "type": "string" },
    "command_id": { "type": "string" },
    "generated_by": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "agent": { "type": "string" },
        "model_a": { "type": "string" },
        "model_b": { "type": "string" }
      },
      "required": ["agent", "model_a", "model_b"]
    },
    "constraints": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "cpu": { "type": "string" },
        "mem": { "type": "string" },
        "disk": { "type": "string" },
        "net": { "type": "string" },
        "rate_limits": { "type": "object" }
      },
      "required": ["cpu", "mem", "disk", "net"]
    },
    "steps": {
      "type": "array",
      "minItems": 1,
      "items": {
        "type": "object",
        "additionalProperties": false,
        "properties": {
          "step_id": { "type": "string" },
          "skill_id": { "type": "string" },
          "tier": { "type": "string", "enum": ["sandbox", "container_build", "host_admin"] },
          "timeout_sec": { "type": "integer", "minimum": 1 },
          "args": { "type": "object" },
          "scope": { "type": "object" },
          "artifacts_expected": {
            "type": "array",
            "items": { "type": "string" }
          }
        },
        "required": ["step_id", "skill_id", "tier", "timeout_sec", "args", "scope", "artifacts_expected"]
      }
    },
    "rollback_plan": { "type": "object" }
  },
  "required": ["plan_id", "plan_hash", "command_id", "generated_by", "constraints", "steps", "rollback_plan"]
}
'''

INCIDENT_SCHEMA = r'''{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "https://arklinux.example.com/schemas/incident-pack.schema.json",
  "title": "Incident Pack Metadata",
  "type": "object",
  "additionalProperties": false,
  "properties": {
    "incident_id": { "type": "string" },
    "created_at": { "type": "string", "format": "date-time" },
    "trigger": { "type": "string" },
    "watchdog_mode": { "type": "string", "enum": ["normal", "halt", "quarantine"] },
    "sal_refs": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "properties": {
          "ref_hash": { "type": "string" },
          "ref_path": { "type": "string" }
        },
        "required": ["ref_hash", "ref_path"]
      }
    },
    "mds_ref": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "ref_hash": { "type": "string" },
        "ref_path": { "type": "string" }
      },
      "required": ["ref_hash", "ref_path"]
    },
    "artifacts": {
      "type": "array",
      "items": {
        "type": "object",
        "additionalProperties": false,
        "properties": {
          "kind": { "type": "string" },
          "ref_hash": { "type": "string" },
          "ref_path": { "type": "string" }
        },
        "required": ["kind", "ref_hash"]
      }
    },
    "telemetry": {
      "type": "object",
      "additionalProperties": true
    },
    "manifest_entry_ref": {
      "type": "object",
      "additionalProperties": false,
      "properties": {
        "ref_hash": { "type": "string" },
        "ref_path": { "type": "string" }
      },
      "required": ["ref_hash", "ref_path"]
    }
  },
  "required": ["incident_id", "created_at", "trigger", "watchdog_mode", "sal_refs", "mds_ref", "manifest_entry_ref"]
}
'''

README = """# arklinux-platform\n\nNormative artifact bundle for the ARKLinux / A.R.K. platform specification.\n\n- docs/: master spec\n- schemas/: SAL/MDS/CPA/VerifiedClaim/Plan/ParameterArtifact + incident pack schema\n- systemd/units/: hardened unit templates\n- network/nftables/: default-deny firewall\n- system/snapshots/: btrfs snapshot tooling\n- manifests/: package manifest template\n"""


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True, help="Output directory")
    ap.add_argument("--assets-dir", default=".", help="Directory containing asset files")
    ap.add_argument("--units-tar", default="systemd_units.tar.gz", help="Tar.gz with systemd unit templates")
    args = ap.parse_args()

    out = Path(args.out).resolve()
    assets_dir = Path(args.assets_dir).resolve()

    if out.exists():
        shutil.rmtree(out)
    (out / "docs").mkdir(parents=True)
    (out / "schemas").mkdir(parents=True)
    (out / "systemd" / "units").mkdir(parents=True)
    (out / "network" / "nftables").mkdir(parents=True)
    (out / "system" / "snapshots").mkdir(parents=True)
    (out / "manifests").mkdir(parents=True)

    # Copy static assets
    for dst_rel, src_name in ASSETS.items():
        src = assets_dir / src_name
        dst = out / dst_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

    # Write additional schemas
    (out / "schemas" / "Plan_schema.json").write_text(PLAN_SCHEMA, encoding="utf-8")
    (out / "schemas" / "incident_pack_schema.json").write_text(INCIDENT_SCHEMA, encoding="utf-8")

    # Extract systemd units
    import tarfile
    units_tar = assets_dir / args.units_tar
    with tarfile.open(units_tar, "r:gz") as tf:
        tf.extractall(path=out)

    # The tarball is expected to contain systemd_units/
    units_dir = out / "systemd_units"
    if units_dir.exists():
        for p in units_dir.iterdir():
            if p.is_file():
                shutil.copy2(p, out / "systemd" / "units" / p.name)
        shutil.rmtree(units_dir)

    (out / "README.md").write_text(README, encoding="utf-8")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
