# arklinux-platform

This repository is a normative artifact bundle for the ARKLinux / A.R.K. platform specification.

Contents:
- `docs/` Master spec document
- `schemas/` JSON Schemas for SAL/MDS/CPA/VerifiedClaim/Plan/ParameterArtifact + incident pack
- `systemd/units/` Hardened service unit templates
- `network/nftables/` Baseline default-deny firewall ruleset
- `system/snapshots/` Btrfs snapshot tooling
- `manifests/` Package manifest template

Note: This bundle is a build substrate and governance artifact set; full archiso profile + installer can be layered on top.
