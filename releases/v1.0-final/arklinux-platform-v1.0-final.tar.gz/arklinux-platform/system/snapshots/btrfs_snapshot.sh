#!/bin/bash
#
# btrfs_snapshot.sh – create read‑only snapshots of core ARKLinux subvolumes.
#
# This script should be run as root during maintenance windows or incident
# triggers to capture the state of important subvolumes.  It stores snapshots
# under /opt/ark/aletheia/immutable/snapshots/<timestamp>/.

set -euo pipefail

SNAP_ROOT="/opt/ark/aletheia/immutable/snapshots"
TIMESTAMP="$(date +%Y%m%d%H%M%S)"

TARGET_DIR="${SNAP_ROOT}/${TIMESTAMP}"

mkdir -p "$TARGET_DIR"

declare -a SUBVOLUMES=("/" "/opt/ark" "/var" "/home")

for SUBVOL in "${SUBVOLUMES[@]}"; do
  # derive a filesystem‑friendly name
  NAME=$(echo "$SUBVOL" | sed 's#^/##' | sed 's#/#-#g')
  # ensure root snapshot name is meaningful
  if [[ "$NAME" == "" ]]; then
    NAME="root"
  fi
  DEST="${TARGET_DIR}/${NAME}"
  echo "Creating read‑only snapshot of ${SUBVOL} at ${DEST}"
  btrfs subvolume snapshot -r "$SUBVOL" "$DEST"
done

echo "Snapshots completed at ${TARGET_DIR}"