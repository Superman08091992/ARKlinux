# ARKLinux/A.R.K. Comprehensive System Specification v1.0

## Specification Index

This document is the master blueprint for a complete ARKLinux deployment.  In addition to the narrative specification below, several normative artifacts must be produced as separate files in order to implement the system end‑to‑end.  The table below lists every artifact that must be created next, with their filenames and brief descriptions.  Once these files are generated you will have a self‑contained, ready‑to‑commit implementation scaffold.

| Artifact | Filename/Path | Purpose |
|---|---|---|
| **Signed Agent Log (SAL) schema** | `schemas/SAL_schema.json` | Defines the structure, required fields and types for each entry in the Signed Agent Log used for evidence and auditing.  Required to validate SAL files during runtime. |
| **Master Directive Snapshot (MDS) schema** | `schemas/MDS_schema.json` | Defines the canonical format of the HRM’s directive snapshot, including approved/denied plans and policy constraints. |
| **Change Proposal Artifact (CPA) schema** | `schemas/CPA_schema.json` | Specifies the format of self‑modification proposals, including diff references, risk assessments and approvals. |
| **VerifiedClaim schema** | `schemas/VerifiedClaim_schema.json` | Defines the structure of claims produced by Aletheia after multi‑source verification, including confidence scores and variance summaries. |
| **ParameterArtifact schema** | `schemas/ParameterArtifact_schema.json` | Describes the allowed shapes of parameter artifacts used by the ID subsystem; enforces “parameters‑only” persistence for the Inner Desire model. |
| **Systemd unit templates** | `systemd_units/` | Contains unit files for each core and optional service (e.g., `ark-policy.service`, `ark-core.service`, `ark-ingestion.service`, `ark-learning.service`, `ark-lattice.service`, `ark-exec.service`, `ark-watchdog.service`, `ark-ui.service`, `ark-federation.service`, `ollama.service`, `redis.service`).  These files embed sandboxing directives, restart policies and readiness gates. |
| **Firewall ruleset** | `nftables/arklinux.nft` | A complete nftables configuration implementing the default‑deny network posture with allowlists for OS updates, federation sync and other controlled egress. |
| **Btrfs snapshot script** | `btrfs_snapshot.sh` | Shell script to create read‑only subvolume snapshots for `/`, `/opt/ark`, `/var`, `/home` and to rotate snapshots on incident triggers using `btrfs subvolume snapshot -r`【763543959220658†L1145-L1166】.  Provides a reversible filesystem checkpoint mechanism. |
| **Package manifest template** | `package_manifest_template.json` | A JSON template enumerating each package, version, install source and checksum.  Used to pin and reproduce the OS build. |

The sections that follow provide detailed descriptions, invariants, lifecycle rules and service boundaries for each subsystem.  Every requirement is tied to at least one external source so that implementers can verify the rationale and context.

## 1 System Definition

### 1.1 What ARKLinux Is

ARKLinux is a hardened **Arch Linux** operating substrate configured to host the A.R.K. multi‑agent system.  Its purpose is to provide deterministic runtime boundaries, service supervision, isolation, cryptographic evidence primitives and operational tooling.  Key elements include:

* **Arch Linux with cgroups v2:**  Arch Linux has used the unified cgroup v2 hierarchy as the default since April 2021【41674520237874†L932-L951】; this allows precise resource accounting and simplifies container isolation.
* **systemd as init:**  systemd manages all services and provides sandboxing features.  Hardening directives such as `NoNewPrivileges=yes`, `MemoryDenyWriteExecute=yes`, `ProtectKernelTunables=yes`, `ProtectKernelModules=yes`, `ProtectHome=yes`, `LockPersonality=yes` and `RestrictSUIDSGID=yes` limit the scope of each service【82146926511541†L183-L200】【881752782574739†L101-L131】.
* **nftables firewall:**  A default‑deny network posture is enforced.  Example base chains on the ArchWiki show that input and forward chains can have a policy of `drop` instead of `accept`【941624570497253†L379-L427】.
* **Podman rootless:**  Containers run as an unprivileged user; rootless Podman isolates container processes and prevents escalation【203914897952552†L215-L224】.
* **btrfs snapshots:**  ARKLinux uses Btrfs with subvolumes for `/`, `/opt/ark`, `/var` and `/home`.  Snapshots are implemented via `btrfs subvolume snapshot source [dest/]name` with the `-r` flag to create read‑only checkpoints【763543959220658†L1145-L1166】.

### 1.2 What A.R.K. Is

A.R.K. is a distributed process collective responsible for governance, continuous learning, multi‑agent reasoning, controlled execution and durable verified memory.  It is not a monolith; each function runs in a separate service.  Major roles include:

| Role | Purpose |
|---|---|
| **Authority enforcement (HRM)** | Verifies agent logs, maintains a master log chain and issues a Master Directive Snapshot (MDS). |
| **Continuous learning (Kyle)** | Ingests data from repositories, telemetry and curated feeds; produces structured claims to be verified. |
| **Verification (Aletheia)** | Verifies claims using at least three independent sources and computes confidence and variance【552856173149817†L40-L74】. |
| **Execution (Kenny)** | Executes approved plans using a skills framework and tier isolation. |
| **Identity (ID)** | Learns a parameterized model of the user’s interaction style; retains only model parameters, never raw data【176608235591787†L88-L97】. |
| **Watchdog** | Monitors policy, chain integrity and resource health; triggers quarantine on failure. |
| **UI/API** | Provides user interaction and instrumentation.

## 2 Root Invariants (Non‑Negotiable Requirements)

The following invariants are enforced structurally; violating them must trigger halt or quarantine.

| Invariant | Rationale & Enforcement |
|---|---|
| **Authority separation** | Agents proposing actions must not authorize them.  Authorization is only through policy evaluation, signed Master Directive Snapshot (MDS) and explicit user authorization.  This aligns with the *separation of duties* principle, which states that no user should be given enough privileges to misuse the system【746173122472463†L183-L186】. |
| **Evidence‑based operation** | All non‑trivial actions produce evidence artifacts stored in an immutable evidence plane.  Evidence is hashed and signed using Ed25519; Ed25519 provides 128‑bit security with small keys and signatures and can verify ~71 k signatures per second【385490041619292†L17-L24】. |
| **Signed log chain governance** | Each agent writes a Signed Agent Log (SAL); logs are chained via hashes and signed.  The HRM aggregates logs, verifies signatures and emits an MDS.  Agents must verify HRM signatures before acting. |
| **Fail‑closed default** | On signature verification failure, chain breakage, policy unavailability or tier violation, execution must halt or be quarantined.  A fail‑closed design ensures that if the system fails it defaults to a secure state rather than allowing unauthorized actions【683025256039458†L54-L75】. |
| **User‑authorized self‑modification** | Self‑modification proposals must follow a formal workflow (create CPA, HRM review, explicit user authorization, controlled apply and attestation). |
| **Dual‑LLM per agent** | Each agent runs LLM‑A (generator) and LLM‑B (verifier).  Communication uses PyTorch’s `torch.distributed` backend.  Gloo is used for CPU and NCCL for GPUs; PyTorch docs recommend `gloo` for CPU and `nccl` for CUDA【795868722989430†L3013-L3292】. |
| **ID parameters‑only persistence** | The ID subsystem persists only parameter artifacts; raw transcripts or tool outputs are prohibited.  Federated‑learning literature notes that in cross‑device FL, devices send only model parameters to a central server while raw data remain on the device【176608235591787†L88-L97】. |
| **Continuous learning + verified memory** | Kyle proposes new knowledge; Aletheia verifies claims using at least three independent sources, reflecting the journalistic practice of source triangulation【552856173149817†L40-L74】. |

## 3 ARKLinux OS Build Specification

### 3.1 Baseline Operating System

* **Distribution:** Arch Linux `x86_64`.
* **Kernel:** Use kernel supporting cgroups v2 and Btrfs.  Ensure `systemd.unified_cgroup_hierarchy=1` on boot.
* **Init:** systemd; cgroups v2 enabled.
* **Packages:** Python 3.11+ (3.12 recommended), Node.js LTS, Redis server, Podman, nftables.  Optional packages: Ollama for local inference; NVIDIA driver + CUDA toolkit + PyTorch with CUDA support.
* **User model:** Create a system user `ark` with nologin; all services run under this account.  Root is reserved for OS maintenance and host_admin tier.  A group `ark` controls shared access.
* **Filesystem:** Use Btrfs with subvolumes `/`, `/opt/ark`, `/var`, `/home`.  Snapshots are created with `btrfs subvolume snapshot -r`【763543959220658†L1145-L1166】.  The canonical root for platform assets is `/opt/ark`.
* **Network:** Use nftables with default policies `drop` on input and forward chains【941624570497253†L379-L427】.  Define allowlist sets for OS updates, market feeds, federation sync and telemetry.
* **Container runtime:** Podman rootless; rootless mode improves security by running containers without root privileges【203914897952552†L215-L224】.  Each service requiring containerization uses Podman pods.
* **cgroups:** Use cgroups v2 for fine‑grained resource control and systemd service budgeting【41674520237874†L932-L951】.

### 3.2 Package Policy & Manifest

Package updates occur only during maintenance windows.  Prior to upgrades, take a Btrfs snapshot of all subvolumes.  Maintain a lockfile‑style manifest (`/opt/ark/aletheia/immutable/manifests/os-packages.<date>.json`) listing each package with fields `name`, `version`, `install_source` and `checksum/signature`.  A template is provided in `package_manifest_template.json`.

### 3.3 Filesystem Permissions and Directories

| Path | Mode | Description |
|---|---|---|
| `/opt/ark` | varies | Canonical root. |
| `/opt/ark/secrets` | `0700` | Contains secrets; accessible only to `ark`. |
| `/opt/ark/aletheia/immutable` | `0700` | Stores SAL, MDS, manifests and evidence; append‑only. |
| `/opt/ark/aletheia/work/verified` | `0750` | Staging area for verified claims before promotion. |
| `/opt/ark/agents/id/params` | `0750` | Parameter artifacts for ID; schema enforced. |
| `/opt/ark/agents/id/eval` | `0750` | Evaluation metrics for ID. |
| `/opt/ark/tmp/sandbox/id` | `0700` | Ephemeral training workspace for ID; cleared after each cycle. |
| Logs (`/opt/ark/logs/<service>/`) | `0750` | Structured JSON logs.  Logs are not authoritative evidence; only SAL/MDS entries constitute evidence. |

### 3.4 Network Design & Firewall

The nftables ruleset defines base chains with default `drop` policy for `input` and `forward` and `accept` for `output`【941624570497253†L379-L427】.  Outbound traffic is denied by default but can be allowed through named sets (`os_update`, `market_feeds`, `federation_sync`, `telemetry`, `connectors`).  A runbook should document how to add entries to these sets.

### 3.5 systemd Hardening Baseline

Services must include sandboxing directives to restrict capabilities.  Based on the ArchWiki and systemd hardening guidelines【82146926511541†L183-L200】【881752782574739†L101-L131】, units should include:

* `NoNewPrivileges=yes` – processes cannot gain additional privileges.
* `PrivateTmp=yes` – isolates `/tmp`.
* `ProtectHome=yes` – makes `/home` inaccessible to the service.
* `ProtectControlGroups=yes` and `ProtectKernelTunables=yes` – restrict access to cgroup and kernel tunables.
* `ProtectKernelModules=yes` – disallows loading kernel modules.
* `LockPersonality=yes` – locks process personality preventing setuid vulnerabilities.
* `RestrictSUIDSGID=yes` – prevents use of set‑uid/set‑gid bits.
* `RestrictRealtime=yes` – disables real‑time scheduling.
* `MemoryDenyWriteExecute=yes` – prevents memory pages from being both writable and executable, mitigating code injection【82146926511541†L183-L200】.
* `SystemCallArchitectures=native` – restrict to native system calls.
* Resource controls such as `CPUQuota`, `MemoryMax`, `TasksMax` and `OOMPolicy=kill` ensure no service monopolises resources.  Each unit should define `Restart=on-failure`, `StartLimitIntervalSec` and `StartLimitBurst` to throttle crash loops.

For containerised services, additional `ReadOnlyPaths` and `ReadWritePaths` directives narrow file system access.

### 3.6 Boot Order & Readiness

Service boot order is orchestrated via `After=` dependencies in systemd units:

1. **local‑fs.target** – ensure mounts and btrfs subvolumes are ready.
2. **nftables.service** – apply firewall rules.
3. **redis.service** – start Redis server.
4. **ark-policy.service** – policy evaluation service.
5. **ark-core.service** – central orchestrator.
6. **ark-ingestion.service** and **ark-learning.service**.
7. **ark-lattice.service** – inter‑agent lattice.
8. **ark-exec.service** – execution workers.
9. **ark-watchdog.service** – monitor health and triggers.
10. **ark-ui.service** – UI/API.

Each service exposes `/health` and `/ready` endpoints.  systemd `ExecStartPre` directives can call scripts to check directory permissions and key availability before starting.  `Restart=on-failure` ensures automatic recovery.

## 4 Process Collective

### 4.1 Core Always‑On Services

| Service | Function | Notes |
|---|---|---|
| **redis.service** | In‑memory data store and message bus.  Uses Redis Streams to model append‑only logs with monotonic IDs【489420082447499†L320-L339】【489420082447499†L352-L371】. |
| **ark-policy.service** | Policy evaluation; produces allow/deny decisions. |
| **ark-core.service** | Core orchestrator that coordinates agent cycles and plan distribution. |
| **ark-ingestion.service (Kyle)** | Continuously ingests sources. |
| **ark-learning.service** | Controls learning promotions and model updates. |
| **ark-lattice.service** | Provides inter‑agent communication fabric. |
| **ark-exec.service (Kenny)** | Executes approved plans; interacts with skills framework and tier isolators. |
| **ark-watchdog.service** | Monitors signature verification, policy availability, SAL chain continuity, constraint violations, crash loops and spool depths; can halt execution and quarantine system. |
| **ark-ui.service** | Front‑end UI and API service. |
| **ollama.service** (optional) | Local inference runtime for LLMs. |
| **ark-federation.service** (optional) | Handles knowledge‑only federation; disabled by default. |

### 4.2 Service Readiness Contract

Each service must implement HTTP endpoints:

* `/health` – returns `200 OK` when the process is alive.
* `/ready` – returns `200 OK` only when all dependencies (e.g., keys loaded, storage writable, network reachable within policy) are satisfied.

systemd units call readiness scripts before marking the service as ready.  If a service fails readiness repeatedly, it should remain in a failed state and the watchdog will decide whether to quarantine or restart.

## 5 Communication Fabric

### 5.1 Intra‑Agent (Dual‑LLM) Communications

Each agent hosts two language model processes (LLM‑A and LLM‑B).  LLM‑A generates candidate plans or outputs; LLM‑B critiques and verifies them.  Communication is via PyTorch `torch.distributed`.  Use `nccl` backend for GPU communications and `gloo` for CPU【795868722989430†L3013-L3292】.  Messages are typed and versioned; message digests are referenced in SAL entries but not necessarily stored in full.

### 5.2 Inter‑Agent Communications

Authority‑carrying messages are transmitted by referencing SAL and MDS entries (hashes and signatures).  Non‑authoritative operational messages may use Redis Streams or local IPC, but any action must ultimately be validated via SAL/MDS chain.

### 5.3 Control‑Plane Communications

Redis Streams channels:

* `events:core`, `events:exec`, `events:watchdog` – publish events.
* `queue:sandbox`, `queue:container_build`, `queue:host_admin` – work queues for sandbox jobs, container builds and host admin tasks.
* `deadletter:*` and `quarantine:*` – hold messages that failed processing or were quarantined.

Redis Streams provide append‑only logs with monotonic IDs and consumer groups for horizontal scaling【489420082447499†L320-L339】【489420082447499†L352-L371】.

## 6 Authority Model

### 6.1 Signed Agent Log (SAL)

The SAL is the atomic evidence unit.  Each entry records inputs, outputs, claims, constraints observed, risk assessments and cryptographic bindings.

**Storage location:** `/opt/ark/aletheia/immutable/audit/sal/<run_id>/<sequence_no>-<agent_id>.json`.

The `SAL_schema.json` file defines the exact JSON schema for SAL.  Key fields include:

* `sal_version` – version string.
* `agent_id` – enumeration of known agents.
* `run_id` – UUID for the agent cycle.
* `sequence_no` – increasing integer.
* `timestamp` – RFC3339 time.
* `inputs` / `outputs` – lists of references (type, hash, path).
* `claims` – array of claims (type, payload, optional confidence and scope).
* `constraints_observed` – object describing policy version, tier, scope hash and limits.
* `risk_assessment` – object with risk level and rationale reference.
* `prev_sal_hash` / `sal_hash` – SHA‑256 digests.
* `signature` – Ed25519 signature over `sal_hash`【385490041619292†L17-L24】.

### 6.2 HRM Master Log & MDS

The HRM (Human Reasoning Module) collects SAL entries, verifies signatures and chain continuity, reconciles claims and computes the authoritative state.  It produces a Master Directive Snapshot (MDS) containing approved and denied plans, global objectives, tier rules, guardrails, ID state and pointers to promoted learning.

**Storage location:** `/opt/ark/aletheia/immutable/audit/mds/<run_id>/<timestamp>.json`.

The `MDS_schema.json` defines fields such as `mds_version`, `run_id`, `effective_timestamp`, `global_objectives`, `constraints`, `approved_plans`, `denied_plans`, `watchdog_state`, `learning_promotions`, `id_state`, `prev_mds_hash`, `mds_hash` and `hrm_signature`.

### 6.3 Verification Rules

Agents must verify the HRM signature, ensure chain continuity and validate recency (e.g., MDS must be within a configurable validity window).  Any failure results in denied execution and triggers the watchdog.  The HRM ensures that conflicting claims are resolved and that only consistent, verified knowledge is promoted.

## 7 Execution System (Kenny) & Tier Isolation

### 7.1 Skills Framework

All actions are executed as **skills**.  A skill is a small, declarative unit with explicit side‑effects and resource scope.

| Field | Description |
|---|---|
| `skill_id` | Namespaced identifier (e.g., `fs.read`, `fs.write_scoped`, `pkg.install`, `container.build`, `repo.scan`, `net.fetch_allowlisted`). |
| `tier_allowed` | Which tier(s) the skill may run in: `sandbox`, `container_build` or `host_admin`. |
| `args_schema` | JSON schema describing allowed arguments. |
| `scope_schema` | Defines filesystem, network and resource boundaries. |
| `side_effects` | Declares side effects (read/write network, file). |
| `audit_requirements` | Specifies evidence that must be captured. |

### 7.2 Command/Plan Model

Execution occurs only through **plans** approved by the HRM.  A plan is a list of steps, each referencing a skill and specifying arguments, scope, tier and timeout.  Plans include constraints (CPU, memory, disk, network) and must define rollback procedures for high‑risk tiers.  Plans are hashed, and the hash is referenced in SAL and MDS.

### 7.3 Tier Enforcement

Three execution tiers enforce isolation:

* **sandbox** – Unprivileged namespace with no network, read‑only filesystem except an isolated workdir, strict CPU/memory/time limits.
* **container_build** – Rootless Podman container with read‑only rootfs and specific bind mounts; egress limited by firewall allowlists; used for building container images and testing self‑mod proposals.
* **host_admin** – Disabled by default; requires explicit user authorization and multi‑factor authentication.  All commands are fully logged, hashed, signed and attested.

## 8 Continuous Learning & Ingestion (Kyle)

Kyle continuously collects signals from repositories, telemetry, external APIs and curated documents.  It normalizes, validates provenance, extracts entities and patterns, classifies them into lattice nodes and memory objects, and produces evidence pointers.  Kyle emits SAL entries that include input hashes, extracted object references and proposed claims but does not promote them to truth; Aletheia is responsible for verification.

## 9 Verified Memory & Truth Pipeline (Aletheia)

Aletheia implements multi‑source verification.  According to source evaluation best practices, corroboration and source triangulation involve seeking multiple independent sources (at least three) to confirm information【552856173149817†L40-L74】.  For each non‑trivial claim, Aletheia:

1. Retrieves ≥3 independent sources where available.
2. Computes a confidence score based on source count, reliability, agreement, evidence strength and recency.
3. Summarizes variance across sources.
4. Produces a `VerifiedClaim` object containing `claim_id`, `statement`, `evidence_refs`, `source_diversity`, `confidence_score`, `variance_summary`, `resolution_steps`, `created_at` and `signature`.

Claims with fewer than three sources are labelled low confidence and logged accordingly.

## 10 ID (“Inner Desire”) Subsystem

The ID subsystem learns a model of the user’s interaction style to predict preferences.  It operates within strict privacy controls:

* **Parameters‑only persistence:**  The ID only persists model parameters and summary metrics; raw interaction transcripts or tool outputs are prohibited.  Federated learning principles show that devices send only local model parameters and keep raw data on the device【176608235591787†L88-L97】.
* **Sandbox:**  Training occurs in an isolated sandbox with no network access.  Write access is restricted to `/opt/ark/tmp/sandbox/id` (ephemeral) and validated directories for parameters and metrics.
* **Write‑path enforcement:**  A schema validator rejects non‑conforming writes; heuristics detect large unstructured blobs; allowed file formats and max sizes are specified.
* **Promotion to autonomy:**  The ID remains advisory until evaluation metrics exceed thresholds for `N` cycles and the HRM records promotion in the MDS.  User must explicitly authorize enabling autonomy.

## 11 Self‑Modification

Self‑modification follows a formal workflow:

1. **Suggestion:**  An agent or user proposes a change.
2. **Change Proposal Artifact (CPA):**  A CPA is created documenting the proposal (`diff_ref`), risk assessment, test plan, rollback plan, approvals required and user authorization record.
3. **Review:**  HRM reviews the proposal; tests are executed in the `container_build` tier.
4. **User authorization:**  The user must explicitly authorize the change.
5. **Apply:**  The change is applied in a controlled environment; attestation is produced, including manifest hashes and test results.
6. **Promotion:**  The change is promoted to production and attested in the immutable evidence plane.

The `CPA_schema.json` defines fields `proposal_id`, `component`, `diff_ref`, `risk_assessment`, `test_plan`, `rollback_plan`, `approvals_required`, `user_authorization_record`, `hrm_signature`, `attestation_ref`.

## 12 Security Model

* **Secrets & key management:**  Secrets reside only in `/opt/ark/secrets` with `0700` permissions.  Each agent has an Ed25519 key pair; signatures are verified using Ed25519, which provides strong security and small signatures【385490041619292†L17-L24】.  Key rotation schedules and revocation lists are published in immutable manifests.
* **RBAC:**  Roles include `viewer`, `operator` and `admin`.  Source‑based constraints differentiate between local UI and remote gateways.  Remote privileged actions are denied by default.

## 13 Reliability & Incident Response

### 13.1 Watchdog Triggers

The watchdog monitors system health and triggers a halt or quarantine on:

* Signature verification failure or SAL chain discontinuity.
* Policy service unavailability.
* Constraint violation (e.g., out‑of‑scope network call, tier violation).
* Worker crash loops exceeding `StartLimitBurst`.
* Deadletter queues exceeding configured thresholds.
* Disk, CPU or memory pressure beyond budgets.

### 13.2 Responses

On critical failures the system enters **HALT** (stop all new execution) or **QUARANTINE** mode (block new work, disable remote ingress).  An incident pack is captured containing the last `N` SAL entries, last MDS, relevant artifacts, telemetry snapshot and manifest entry.  Re‑activation requires an admin reset and reason.

## 14 Observability

* **Logs:**  Structured JSON logs per service at `/opt/ark/logs/<service>/`.  Logs are for observability and debugging; they are not authoritative evidence.  SAL/MDS entries constitute the authoritative audit trail.
* **Metrics:**  Expose queue depths, stage latencies, signature verification failures, watchdog trips, disk/memory pressure and ID evaluation metrics.  Metrics are exported to Prometheus or a similar monitoring backend.

## 15 Testing & Acceptance

### 15.1 Mandatory Tests

1. SAL signing and verification correctness (including chain integrity).
2. MDS signature verification enforcement.
3. Policy service fail‑closed (deny if policy service down).
4. Tier enforcement (sandbox: no network; container_build: limited egress; host_admin: disabled by default).
5. ID persistence guard rejects raw transcripts; accepts only parameter artifacts.
6. Self‑modification cannot apply without user authorization record; attestation is generated.
7. Aletheia verification pipeline produces confidence and variance summaries; promotion requires HRM approval.

### 15.2 Acceptance Gates

The system is considered “as designed” only when:

* Authority chain (SAL → HRM master log → MDS) is operational end‑to‑end.
* Evidence manifests verify and signatures are correct.
* Quarantine procedures work as expected (fail‑closed).  
* Tier isolation prevents unauthorized network or filesystem access.
* Continuous learning and verified memory pipelines function; claims are verified using ≥3 sources【552856173149817†L40-L74】.
* ID parameters‑only enforcement works; no raw data is persisted【176608235591787†L88-L97】.
* Self‑modification workflow is enforced and fully attested.

## 16 Deliverables Checklist

The engineering team must produce the following deliverables (the first items correspond to the specification index at the start of this document):

* Complete JSON schemas: SAL, MDS, CPA, VerifiedClaim, ParameterArtifact.
* systemd unit files for all services with proper dependencies and sandboxing directives.
* nftables ruleset with default deny and allowlist sets.
* Btrfs subvolume creation and snapshot scripts.
* Package manifest template enumerating pinned versions.
* Dual‑LLM runtime template using `torch.distributed` with `gloo`/`nccl` backends.
* HRM master log implementation and MDS publisher.
* Ingestion pipelines (Kyle) and verification engine (Aletheia).
* ID sandbox implementation with parameter persistence guards.
* Self‑modification workflow implementation with CPA generation and attestation.
* UI console for lifecycle management, chain status, approvals and audit viewing.